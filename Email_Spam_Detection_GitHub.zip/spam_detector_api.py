from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()

# Dummy classifier logic (replace with real model)
def predict_spam(email_text: str) -> str:
    # In real usage, load your model here
    # For demo purposes, classify anything with "offer" as spam
    return "spam" if "offer" in email_text.lower() else "ham"

# Request model
class EmailInput(BaseModel):
    subject: str
    body: str

@app.post("/predict")
def predict_email(data: EmailInput):
    combined_text = f"{data.subject} {data.body}"
    result = predict_spam(combined_text)
    if result == "spam":
        raise HTTPException(status_code=400, detail="Email classified as SPAM")
    return {"result": result}
