# Email Spam Detection API using FastAPI 🚀

This project implements a Machine Learning-based spam email classification system using Linear SVC and Random Forest classifiers. The model is served via a FastAPI application and is designed for scalable deployment using AWS Lambda and SES.

## 🔍 Project Overview
- **Model**: Linear SVC / Random Forest
- **Framework**: FastAPI
- **Deployment Target**: AWS Lambda via API Gateway
- **Email Handling**: AWS SES

## 🧠 ML Pipeline
1. Preprocess input email data
2. Use trained ML model to predict spam/ham
3. Return response via API
4. Prevent email sending if spam (SES block)

## 📁 File Structure
- `spam_detector_api.py`: FastAPI app with prediction logic
- `requirements.txt`: Required Python packages
- `README.md`: This file

## ⚙️ How to Run (Locally)
```bash
pip install -r requirements.txt
uvicorn spam_detector_api:app --reload
```

Visit `http://127.0.0.1:8000/docs` for interactive API.

## 🔐 AWS Integration
- **Lambda**: Host FastAPI via Mangum
- **SES**: Secure email sending after spam check
- **IAM Roles**: Scoped access for Lambda + SES

## 🧩 Future Improvements
- Add UI dashboard
- Train on larger dataset
- Continuous model learning from feedback

---
*Developed by Pagidakula Akshara @ CITD, Hyderabad*
